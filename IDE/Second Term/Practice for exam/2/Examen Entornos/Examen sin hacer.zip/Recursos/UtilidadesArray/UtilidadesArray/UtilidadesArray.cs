﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace UtilidadesArray
{
    public class UtilidadesArray
    {
        public int[] ordenarArray(int[] a)
        {
            check_Array(a);

            // Variables para almacenar el array una vez este ordenado
            int[] ao = new int[a.Length];

            //Recorremos el array
            for (int x = 0; x < a.Length; x++)
            {
                // El -1 es porque no queremos llegar al final ya que hacemos
                // un indiceActual + 1 y si fuéramos hasta el final, intentaríamos acceder a un valor fuera de los límites
                // del arreglo
                for (int y = 0; y < a.Length - 1; y++)
                {
                    // guardamos el indice del siguiente elemento
                    int ins = y + 1;

                    // Si el actual es mayor que el que le sigue a la derecha...
                    if (a[y] > a[ins])
                    {
                        // Guardamos en una variable temporal el resultado
                        int t = a[y];
                        a[y] = a[ins];
                        a[ins] = t;
                    }
                }
            }

            //Copiamos el array una vez ordenado en la variable designada para ello
            Array.Copy(a, ao, a.Length);

            return ao;
        }

        // El primer elemento es el array a buscar, el segundo el numero que buscamos
        public int buscarElementoArray(int[] a, int b)
        {
            check_Array(a);

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == b)
                    return i;
            }
            return -1;
        }

        // El primer elemento es el array sobre el que buscamos
        private void check_Array(int[] a)
        {
            if (a == null)
                throw new ArgumentNullException("El array no puede ser nulo");
            else if (a.Length == 0)
                throw new ArgumentOutOfRangeException("El array no puede estar vacío");                
        }
    }
}
