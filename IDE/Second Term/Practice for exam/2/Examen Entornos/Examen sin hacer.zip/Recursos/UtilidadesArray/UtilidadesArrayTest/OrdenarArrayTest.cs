namespace UtilidadesArrayTest
{
    using UtilidadesArray;

    [TestClass]
    public class OrdenarArrayTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            int[] arr = { 78, 55, 45, 98, 13 };
            int[] arr2;

            UtilidadesArray utilidades = new UtilidadesArray();
            arr2 = utilidades.ordenarArray(arr);

            Assert.AreEqual(arr2[0], 13);
            Assert.AreEqual(arr2[1], 45);
            Assert.AreEqual(arr2[2], 55);
            Assert.AreEqual(arr2[3], 78);
            Assert.AreEqual(arr2[4], 98);
        }
    }
}