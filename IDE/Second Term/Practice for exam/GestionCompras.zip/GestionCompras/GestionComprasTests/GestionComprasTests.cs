﻿using Gestion;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace GestionComprasTests
{
    [TestClass]
    public class GestionComprasTests
    {
        [TestMethod]
        public void RegistrarCompraAgregaProductoInventario()
        {
            // Preparacion
            GestionCompras gestionCompras = new GestionCompras();

            // Actuacion
            gestionCompras.RegistrarCompra("ProductoA", 5);

            // Comprobacion
            Assert.AreEqual(5, gestionCompras.ObtenerInventario("ProductoA"));
        }
    }
}
