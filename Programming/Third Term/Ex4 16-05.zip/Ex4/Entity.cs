﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex4
{
    public abstract class Entity
    {
        // We will use this class as the parent of every other class. Including Person, and Courses
        public Entity() { }
    }
}
